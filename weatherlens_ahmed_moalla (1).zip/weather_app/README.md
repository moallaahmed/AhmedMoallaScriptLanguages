# WeatherLens 🌤️

**A real-time weather web application built with Flask and Open-Meteo API**

> Semester Project — Scripting Languages (Python)
> **Author:** Ahmed Moalla

---

## Description

WeatherLens is a full-stack web application that allows users to search for real-time weather data for any city in the world. It displays dynamic temperature charts, a 7-day forecast, and maintains a full history of past queries with CRUD operations — all backed by a SQLite database.

---

## Features

- 🔍 **City Search** — geocodes any city name worldwide
- 🌡️ **Current Conditions** — temperature, feels-like, humidity, wind speed, weather description
- 📊 **Hourly Temperature Chart** — dynamic Chart.js line chart for today's 24h data
- 📅 **7-Day Forecast** — daily min/max temperatures
- 🕓 **Query History** — full CRUD (Create, Read, Delete) with chart overview
- ⭐ **Favorites** — save cities for quick access
- 🌐 **No API key required** — uses the free Open-Meteo API

---

## Technical Stack

| Layer        | Technology                 |
|--------------|----------------------------|
| Language     | Python 3.8+                |
| Framework    | Flask 3.0                  |
| Database     | SQLite via Flask-SQLAlchemy|
| External API | Open-Meteo (free, no key)  |
| Charts       | Chart.js 4.4               |
| UI fonts     | Space Grotesk + Space Mono |

---

## Project Structure

```
weather_app/
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── instance/
│   └── weather.db          # SQLite database (auto-created)
├── templates/
│   ├── base.html           # Base layout
│   ├── index.html          # Home / Search page
│   ├── weather.html        # Weather results + charts
│   ├── history.html        # Query history
│   └── 404.html            # Error page
└── static/
    └── css/
        └── style.css       # All styling
```

---

## How to Run Locally

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/weatherlens.git
cd weatherlens
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv
source venv/bin/activate       # Linux/Mac
venv\Scripts\activate          # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the application
```bash
python app.py
```

### 5. Open in browser
```
http://localhost:5000
```

---

## System Requirements

- Python 3.8 or higher
- pip
- Internet connection (to fetch weather data)
- See `requirements.txt` for all Python packages

---

## CRUD Operations

| Operation | Description                             | Route                       |
|-----------|-----------------------------------------|-----------------------------|
| Create    | Save new weather query to history       | `POST /weather`             |
| Create    | Add city to favorites                   | `POST /favorites/add`       |
| Read      | View all history                        | `GET /history`              |
| Read      | JSON API for history data               | `GET /api/history`          |
| Delete    | Remove a single history entry           | `POST /history/delete/<id>` |
| Delete    | Clear all history                       | `POST /history/clear`       |
| Delete    | Remove a favorite                       | `POST /favorites/delete/<id>`|

---

## API Used

**Open-Meteo** — Free, open-source weather API. No API key required.
- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- Weather: `https://api.open-meteo.com/v1/forecast`
- Documentation: https://open-meteo.com/en/docs

---

## PEP 8 Compliance

The code follows PEP 8 guidelines:
- Functions and variables use `snake_case`
- Classes use `PascalCase`
- Maximum line length: 88 characters
- Docstrings on all functions and classes
- Logical grouping with section comments

---

## Error Handling

- Invalid city names return a friendly flash message
- API timeouts are caught and reported gracefully
- 404 and 500 pages are handled
- All form inputs are validated before processing
