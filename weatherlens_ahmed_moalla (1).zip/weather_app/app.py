"""
WeatherLens - Flask Weather Application
Author: Ahmed Moalla
Description: A web application that fetches real-time weather data via the Open-Meteo API,
             displays dynamic temperature charts, and stores query history in SQLite.
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = 'weatherlens-secret-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///weather.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


# ─── Models ───────────────────────────────────────────────────────────────────

class QueryHistory(db.Model):
    """Stores every weather query made by the user."""
    id = db.Column(db.Integer, primary_key=True)
    city = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(100), nullable=True)
    temperature = db.Column(db.Float, nullable=True)
    weather_description = db.Column(db.String(200), nullable=True)
    humidity = db.Column(db.Integer, nullable=True)
    wind_speed = db.Column(db.Float, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'city': self.city,
            'country': self.country,
            'temperature': self.temperature,
            'weather_description': self.weather_description,
            'humidity': self.humidity,
            'wind_speed': self.wind_speed,
            'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M'),
            'latitude': self.latitude,
            'longitude': self.longitude,
        }


class FavoriteCity(db.Model):
    """Stores user's favorite cities for quick access."""
    id = db.Column(db.Integer, primary_key=True)
    city = db.Column(db.String(100), nullable=False, unique=True)
    country = db.Column(db.String(100), nullable=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'city': self.city,
            'country': self.country,
            'latitude': self.latitude,
            'longitude': self.longitude,
        }


# ─── Weather API Helpers ───────────────────────────────────────────────────────

WMO_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Foggy", 48: "Icy fog", 51: "Light drizzle", 53: "Moderate drizzle",
    55: "Heavy drizzle", 61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow", 80: "Rain showers",
    81: "Moderate showers", 82: "Heavy showers", 95: "Thunderstorm",
    96: "Thunderstorm with hail", 99: "Thunderstorm with heavy hail",
}


def geocode_city(city_name: str) -> dict | None:
    """Convert city name to coordinates using Open-Meteo Geocoding API."""
    try:
        url = "https://geocoding-api.open-meteo.com/v1/search"
        params = {"name": city_name, "count": 1, "language": "en", "format": "json"}
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if data.get("results"):
            r = data["results"][0]
            return {
                "name": r.get("name", city_name),
                "country": r.get("country", ""),
                "latitude": r["latitude"],
                "longitude": r["longitude"],
            }
    except requests.RequestException:
        pass
    return None


def fetch_weather(lat: float, lon: float) -> dict | None:
    """Fetch current weather from Open-Meteo (no API key required)."""
    try:
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat,
            "longitude": lon,
            "current": [
                "temperature_2m", "relative_humidity_2m",
                "wind_speed_10m", "weather_code", "apparent_temperature",
            ],
            "hourly": "temperature_2m",
            "forecast_days": 1,
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException:
        return None


def fetch_7day_forecast(lat: float, lon: float) -> dict | None:
    """Fetch 7-day daily forecast."""
    try:
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat,
            "longitude": lon,
            "daily": ["temperature_2m_max", "temperature_2m_min", "weather_code"],
            "timezone": "auto",
            "forecast_days": 7,
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException:
        return None


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """Home page with search form and recent queries."""
    recent = QueryHistory.query.order_by(QueryHistory.timestamp.desc()).limit(5).all()
    favorites = FavoriteCity.query.order_by(FavoriteCity.added_at.desc()).all()
    return render_template('index.html', recent=recent, favorites=favorites)


@app.route('/weather', methods=['POST'])
def weather():
    """Handle weather search and save to history."""
    city = request.form.get('city', '').strip()
    if not city:
        flash('Please enter a city name.', 'error')
        return redirect(url_for('index'))

    geo = geocode_city(city)
    if not geo:
        flash(f'Could not find city: "{city}". Please check the spelling.', 'error')
        return redirect(url_for('index'))

    weather_data = fetch_weather(geo['latitude'], geo['longitude'])
    if not weather_data:
        flash('Weather service is temporarily unavailable. Please try again.', 'error')
        return redirect(url_for('index'))

    current = weather_data['current']
    wmo_code = current.get('weather_code', 0)
    description = WMO_CODES.get(wmo_code, 'Unknown')

    # Save to history (CRUD - Create)
    entry = QueryHistory(
        city=geo['name'],
        country=geo['country'],
        temperature=current.get('temperature_2m'),
        weather_description=description,
        humidity=current.get('relative_humidity_2m'),
        wind_speed=current.get('wind_speed_10m'),
        latitude=geo['latitude'],
        longitude=geo['longitude'],
    )
    db.session.add(entry)
    db.session.commit()

    # Hourly chart data
    hourly_temps = weather_data.get('hourly', {}).get('temperature_2m', [])
    hourly_labels = [f"{i:02d}:00" for i in range(len(hourly_temps))]

    # 7-day forecast
    forecast_data = fetch_7day_forecast(geo['latitude'], geo['longitude'])
    forecast = []
    if forecast_data and 'daily' in forecast_data:
        d = forecast_data['daily']
        for i in range(len(d.get('time', []))):
            forecast.append({
                'date': d['time'][i],
                'max': d['temperature_2m_max'][i],
                'min': d['temperature_2m_min'][i],
                'desc': WMO_CODES.get(d['weather_code'][i], 'Unknown'),
            })

    return render_template(
        'weather.html',
        city=geo['name'],
        country=geo['country'],
        temperature=current.get('temperature_2m'),
        feels_like=current.get('apparent_temperature'),
        description=description,
        humidity=current.get('relative_humidity_2m'),
        wind_speed=current.get('wind_speed_10m'),
        hourly_labels=hourly_labels,
        hourly_temps=hourly_temps,
        forecast=forecast,
        lat=geo['latitude'],
        lon=geo['longitude'],
    )


@app.route('/history')
def history():
    """View all query history (CRUD - Read)."""
    queries = QueryHistory.query.order_by(QueryHistory.timestamp.desc()).all()
    return render_template('history.html', queries=queries)


@app.route('/history/delete/<int:entry_id>', methods=['POST'])
def delete_history(entry_id):
    """Delete a history entry (CRUD - Delete)."""
    entry = QueryHistory.query.get_or_404(entry_id)
    db.session.delete(entry)
    db.session.commit()
    flash('History entry deleted.', 'success')
    return redirect(url_for('history'))


@app.route('/history/clear', methods=['POST'])
def clear_history():
    """Clear all history."""
    QueryHistory.query.delete()
    db.session.commit()
    flash('History cleared.', 'success')
    return redirect(url_for('history'))


@app.route('/favorites/add', methods=['POST'])
def add_favorite():
    """Add a city to favorites (CRUD - Create)."""
    city = request.form.get('city', '').strip()
    country = request.form.get('country', '')
    lat = request.form.get('lat')
    lon = request.form.get('lon')

    existing = FavoriteCity.query.filter_by(city=city).first()
    if existing:
        flash(f'{city} is already in your favorites.', 'info')
    else:
        fav = FavoriteCity(city=city, country=country, latitude=lat, longitude=lon)
        db.session.add(fav)
        db.session.commit()
        flash(f'{city} added to favorites!', 'success')
    return redirect(url_for('index'))


@app.route('/favorites/delete/<int:fav_id>', methods=['POST'])
def delete_favorite(fav_id):
    """Remove from favorites (CRUD - Delete)."""
    fav = FavoriteCity.query.get_or_404(fav_id)
    db.session.delete(fav)
    db.session.commit()
    flash(f'{fav.city} removed from favorites.', 'success')
    return redirect(url_for('index'))


@app.route('/api/history')
def api_history():
    """JSON endpoint for history data (for charts on history page)."""
    queries = QueryHistory.query.order_by(QueryHistory.timestamp.desc()).limit(20).all()
    return jsonify([q.to_dict() for q in queries])


@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('404.html', error="Internal server error."), 500


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
