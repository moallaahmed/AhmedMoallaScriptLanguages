# WeatherLens — Presentation Guide (10–15 min)
## Ahmed Moalla

---

## OPENING (1 min)

> "Good morning. My project is called **WeatherLens** — a real-time weather web application built with Python and Flask. The idea is simple: you type any city name, and the app fetches live weather data, draws a temperature chart, and saves your search history in a database."

---

## 1. PROJECT OVERVIEW (1 min)

Say:
- Language: **Python 3**, framework: **Flask**
- External API: **Open-Meteo** (free, no API key needed)
- Database: **SQLite** via **Flask-SQLAlchemy**
- Charts: **Chart.js** (interactive, dynamic)
- Interface: web browser (SPA feel with clean dark UI)

---

## 2. LIVE DEMO — SEARCH (3 min)

**Do this:**
1. Open `http://localhost:5000` in the browser
2. Type **"Paris"** → click Search
3. Point out on the results page:
   - Current temperature, feels-like, humidity, wind speed
   - **Hourly temperature chart** (animated line chart)
   - **7-day forecast** cards
4. Say: *"The search is geocoded — it converts the city name to GPS coordinates, then calls the weather API with those coordinates."*

---

## 3. LIVE DEMO — FAVORITES & HISTORY (2 min)

**Do this:**
1. Click **☆ Save to Favorites** on the Paris result
2. Go back to home — show Paris appears in Favorites panel
3. Search **"Tokyo"**, then **"New York"**
4. Click **History** in the navbar
5. Show the **bar chart** across all searches
6. Show the table with all entries
7. Delete one entry — show it disappears

Say: *"This gives us full CRUD operations — Create when we search, Read in the history table, Delete for individual entries or clearing all. I also added a JSON API endpoint at `/api/history` that returns the data for the chart."*

---

## 4. CODE WALKTHROUGH (4 min)

Open `app.py` and point to these sections:

### Models (line ~20)
```python
class QueryHistory(db.Model):
```
> "Two SQLAlchemy models: QueryHistory stores every search, FavoriteCity stores saved cities. Both have a `to_dict()` method for the JSON API."

### Geocoding (line ~60)
```python
def geocode_city(city_name):
```
> "This uses Open-Meteo's free geocoding API to convert a city name into latitude and longitude."

### Weather fetch (line ~80)
```python
def fetch_weather(lat, lon):
```
> "Then I use those coordinates to get current conditions and a 24-hour hourly forecast."

### Main route (line ~110)
```python
@app.route('/weather', methods=['POST'])
def weather():
```
> "This route validates the input, calls both API helpers, saves the result to the database, then renders the template with all the data including the hourly chart arrays."

### Error handling
> "All API calls are wrapped in try/except with timeout. Invalid cities show a flash message. There are 404 and 500 error pages."

---

## 5. TECHNICAL REQUIREMENTS CHECK (1 min)

Quickly say each one:

| Requirement | ✅ |
|---|---|
| Python 3.8+ | ✅ Flask app |
| Custom functions | ✅ `geocode_city()`, `fetch_weather()`, `fetch_7day_forecast()` |
| Classes (OOP) | ✅ Two SQLAlchemy model classes |
| External library | ✅ `requests`, `flask-sqlalchemy`, Chart.js |
| Input/output file handling | ✅ SQLite database (read/write) |
| GUI/web interface | ✅ Flask + HTML templates |
| Database + CRUD | ✅ SQLite, full Create/Read/Delete |
| Error handling | ✅ try/except, flash messages, 404/500 pages |
| README | ✅ Full README with setup instructions |
| GitHub | ✅ Repository with history |
| PEP 8 | ✅ snake_case, docstrings, 88-char lines |
| Innovation | ✅ Real external API + no API key needed |

---

## 6. CLOSING (30 sec)

> "WeatherLens checks all the requirements: Flask web app, SQLite database with CRUD, external API integration, interactive charts, error handling, and clean code structure. The biggest challenge was chaining two API calls — geocoding first, then weather — and handling failures at either step gracefully. Thank you."

---

## LIKELY QUESTIONS & ANSWERS

**Q: Why Open-Meteo and not OpenWeatherMap?**
> Open-Meteo is completely free with no API key, which makes it easier to run locally without any setup. It also provides hourly data in one call.

**Q: What happens if the user types a wrong city?**
> The geocoding API returns nothing, we catch that and show a flash error message. The user stays on the home page.

**Q: Where is the database stored?**
> In the `instance/` folder as `weather.db`. SQLAlchemy creates it automatically on first run.

**Q: Could this be extended?**
> Yes — I could add user authentication, export to CSV, weather alerts, or a map integration. The modular structure makes it easy to add routes and models.
